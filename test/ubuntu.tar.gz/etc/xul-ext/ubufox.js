// Place your global Firefox preferences in this file if you are using
// ubufox. Especially those preferences defined in ubufox need to be configured
// here to become effective.

// Example: Homepage
//pref("browser.startup.homepage", "file:/usr/share/doc/xul-ext-ubufox/example-homepage.properties");
